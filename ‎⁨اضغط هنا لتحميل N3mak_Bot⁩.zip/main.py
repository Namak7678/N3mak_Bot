
import telebot
from modules.handlers import register_handlers
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(BOT_TOKEN)

register_handlers(bot)

print("✅ بوت N3mak_Bot يعمل الآن...")
bot.polling(none_stop=True)
