
def register_handlers(bot):
    @bot.message_handler(commands=['start', 'ابدأ'])
    def welcome(message):
        bot.reply_to(message, (
            "👋 مرحباً بك في N3mak_Bot!\n"
            "أنا مساعدك الذكي لاكتشاف المكافآت وربط المحافظ\n"
            "/ذكاء_اصطناعي – استخدم الذكاء الاصطناعي\n"
            "/ربط_محفظة – اربط محفظتك\n"
            "/دعم – تحدث مع الدعم"
        ), parse_mode="Markdown")

    @bot.message_handler(commands=['ذكاء_اصطناعي'])
    def ai_reply(message):
        bot.reply_to(message, "🧠 اكتب سؤالك وسأساعدك باستخدام الذكاء الاصطناعي.")
